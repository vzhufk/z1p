module.exports = [
  {
    accuracy: "4",
    community: "",
    community_code: "",
    country_code: "MH",
    latitude: "11.1405",
    longitude: "166.4103",
    place: "Majuro",
    province: "Ailinginae",
    province_code: "007",
    state: "Mh",
    state_code: "68",
    zip_code: "96960"
  },
  {
    accuracy: "4",
    community: "",
    community_code: "",
    country_code: "MH",
    latitude: "11.1405",
    longitude: "166.4103",
    place: "Ebeye",
    province: "Ailinginae",
    province_code: "007",
    state: "Mh",
    state_code: "68",
    zip_code: "96970"
  }
];

module.exports = [
  {
    accuracy: "1",
    community: "",
    community_code: "",
    country_code: "PW",
    latitude: "7.2257",
    longitude: "134.3622",
    place: "Palau",
    province: "",
    province_code: "",
    state: "",
    state_code: "",
    zip_code: "96940"
  }
];

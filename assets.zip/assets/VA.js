module.exports = [
  {
    accuracy: "4",
    community: "",
    community_code: "",
    country_code: "VA",
    latitude: "41.9024",
    longitude: "12.4533",
    place: "Citta' Del Vaticano",
    province: "",
    province_code: "",
    state: "",
    state_code: "",
    zip_code: "00120"
  }
];

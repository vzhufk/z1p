module.exports = [
  {
    accuracy: "6",
    community: "",
    community_code: "",
    country_code: "MP",
    latitude: "14.154",
    longitude: "145.201",
    place: "Rota",
    province: "",
    province_code: "",
    state: "Rota",
    state_code: "100",
    zip_code: "96951"
  },
  {
    accuracy: "6",
    community: "",
    community_code: "",
    country_code: "MP",
    latitude: "15.1685",
    longitude: "145.7408",
    place: "Saipan",
    province: "",
    province_code: "",
    state: "Saipan",
    state_code: "110",
    zip_code: "96950"
  },
  {
    accuracy: "6",
    community: "",
    community_code: "",
    country_code: "MP",
    latitude: "15.029",
    longitude: "145.616",
    place: "Tinian",
    province: "",
    province_code: "",
    state: "Tinian",
    state_code: "120",
    zip_code: "96952"
  }
];

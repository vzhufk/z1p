module.exports = [
  {
    accuracy: "1",
    community: "",
    community_code: "",
    country_code: "FM",
    latitude: "7.1383",
    longitude: "151.5031",
    place: "Kosrae",
    province: "",
    province_code: "",
    state: "State of Kosrae",
    state_code: "01",
    zip_code: "96944"
  },
  {
    accuracy: "1",
    community: "",
    community_code: "",
    country_code: "FM",
    latitude: "7.1383",
    longitude: "151.5031",
    place: "Pohnpei",
    province: "",
    province_code: "",
    state: "State of Pohnpei",
    state_code: "02",
    zip_code: "96941"
  },
  {
    accuracy: "1",
    community: "",
    community_code: "",
    country_code: "FM",
    latitude: "7.1383",
    longitude: "151.5031",
    place: "Chuuk",
    province: "",
    province_code: "",
    state: "State of Chuuk",
    state_code: "03",
    zip_code: "96942"
  },
  {
    accuracy: "4",
    community: "",
    community_code: "",
    country_code: "FM",
    latitude: "7.1383",
    longitude: "151.5031",
    place: "Yap",
    province: "",
    province_code: "",
    state: "State of Yap",
    state_code: "04",
    zip_code: "96943"
  }
];

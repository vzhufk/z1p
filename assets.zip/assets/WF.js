module.exports = [
  {
    accuracy: "5",
    community: "",
    community_code: "",
    country_code: "WF",
    latitude: "-14.3066",
    longitude: "-178.1188",
    place: "Alo",
    province: "",
    province_code: "",
    state: "Circonscription d'Alo",
    state_code: "98611",
    zip_code: "98610"
  },
  {
    accuracy: "5",
    community: "",
    community_code: "",
    country_code: "WF",
    latitude: "-14.2667",
    longitude: "-178.1667",
    place: "Sigave",
    province: "",
    province_code: "",
    state: "Circonscription de Sigave",
    state_code: "98612",
    zip_code: "98620"
  },
  {
    accuracy: "5",
    community: "",
    community_code: "",
    country_code: "WF",
    latitude: "-13.2988",
    longitude: "-176.2205",
    place: "Uvéa",
    province: "",
    province_code: "",
    state: "Circonscription d'Uvéa",
    state_code: "98613",
    zip_code: "98600"
  }
];

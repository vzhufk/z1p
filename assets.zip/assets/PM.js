module.exports = [
  {
    accuracy: "5",
    community: "",
    community_code: "",
    country_code: "PM",
    latitude: "47.0975",
    longitude: "-56.3814",
    place: "Miquelon",
    province: "Miquelon-Langlade",
    province_code: "97501",
    state: "Miquelon-Langlade",
    state_code: "97501",
    zip_code: "97500"
  },
  {
    accuracy: "5",
    community: "",
    community_code: "",
    country_code: "PM",
    latitude: "46.7809",
    longitude: "-56.172",
    place: "Saint-Pierre",
    province: "",
    province_code: "",
    state: "Saint-Pierre",
    state_code: "97502",
    zip_code: "97500"
  }
];

module.exports = [
  {
    accuracy: "",
    community: "",
    community_code: "",
    country_code: "JE",
    latitude: "49.2",
    longitude: "-2.1333",
    place: "St Helier",
    province: "Jersey Channel Islands",
    province_code: "",
    state: "",
    state_code: "",
    zip_code: "JE1"
  },
  {
    accuracy: "",
    community: "",
    community_code: "",
    country_code: "JE",
    latitude: "49.2",
    longitude: "-2.1333",
    place: "St Helier",
    province: "Jersey Channel Islands",
    province_code: "",
    state: "",
    state_code: "",
    zip_code: "JE2"
  },
  {
    accuracy: "",
    community: "",
    community_code: "",
    country_code: "JE",
    latitude: "49.2",
    longitude: "-2.1333",
    place: "St Brelades",
    province: "Jersey Channel Islands",
    province_code: "",
    state: "",
    state_code: "",
    zip_code: "JE3"
  },
  {
    accuracy: "",
    community: "",
    community_code: "",
    country_code: "JE",
    latitude: "49.2",
    longitude: "-2.1333",
    place: "St Lawrence",
    province: "Jersey Channel Islands",
    province_code: "",
    state: "",
    state_code: "",
    zip_code: "JE3"
  }
];

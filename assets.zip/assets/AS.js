module.exports = [
  {
    accuracy: "6",
    community: "",
    community_code: "",
    country_code: "AS",
    latitude: "-14.2781",
    longitude: "-170.7025",
    place: "Pago Pago",
    province: "Western",
    province_code: "050",
    state: "As",
    state_code: "60",
    zip_code: "96799"
  }
];
